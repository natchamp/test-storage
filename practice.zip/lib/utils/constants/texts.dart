class TTexts {
  //constant texts

  //onboarding headings
  static const String obH1 = "Heading 1";
  static const String obH2 = "Heading 2";
  static const String obH3 = "Heading 3";

  //onboarding texts
  static const String obT1 = "Text 1";
  static const String obT2 = "Text 2";
  static const String obT3 = "Text 3";

  //login texts
  static const String loginSubTitle = "Please Login to continue";
  static const String loginTitle = "Welcome back,";

  //Login form texts
  static const String firstName = "First Name";
  static const String lastName = "Last Name";
  static const String email = "Email";
  static const String password = "Password";
  static const String rememberMe = "Remember Me";
  static const String forgotPassword = "Forgot Password?";
  static const String signIn = "Sign In";
  static const String createAcc = "Create Account";
  static const String orSignIn = "or Sign in with";
  // static const String

  //sign up form texts
  static const String signupTitle = "Lets create your account";
  static const String username = "username";
  static const String phoneNumber = 'Phone Number';
  static const String iAgreeTo = "I Agreee To";
  static const String and = "and";
  static const String privacyPolicy = "Privacy Policy";
  static const String termsOfUse = "Terms of Use";
  static const String orSignUpWith = " or Sign up with";

  //Confirm Email
  static const String confirmEmail = "Verify you email address!";
  static const String confirmEmailSubTitle =
      "Congratulations! Your account Awaits. Verify Your Email to Start using App";
  static const String tContinue = "Continue";
  static const String resendEmail = "Resend Email";
  static const String yourAccCreatedTitle = "Your acount created successfully!";
  static const String yourAccCreatedSubTitle =
      "Welcome to your ultimate society management app. Your acount is created.";

  //Forgot Password
  static const String submit = "Submit";
  static const String done = "Done";
  static const String forgetPasswordTitle = "Forword Password?";
  static const String forgetPasswordSubTitle =
      "Don't worry sometimes people can forget too, enter your email and we will send you a password reset link";

  static const String changeYourPasswordTitle = "Password Reset Email Sent";
  static const String changeYourPasswordSubTitle =
      "Your account security is our priority! We've sent you a secure link to safelt change your password and keep your account protected.";
}
