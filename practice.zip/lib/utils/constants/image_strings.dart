class TImages {
  static const String darkAppLogo = "assets/logos/logo2.png";
  static const String lightAppLogo = "assets/logos/logo2.png";

  static const String google = "assets/images/social_media/google.png";
  static const String facebook = "assets/images/social_media/facebook.png";

  static const String test = "assets/logos/logo2.png";
  static const String ob1 =
      "assets/images/on_boarding_images/sammy-line-phone-with-map-and-geolocation.gif";
  static const String ob2 =
      "assets/images/on_boarding_images/bubble-gum-otp-verification.gif";
  static const String ob3 =
      "assets/images/on_boarding_images/sammy-line-phone-with-map-and-geolocation.gif";

  static const String deliveredEmailIllustration =
      "assets/images/social_media/email_verification.gif";

  static const String staticSuccessIllustration =
      "assets/images/social_media/email_verify_success.gif";

  static const String emailSent = "assets/images/social_media/email_sent2.gif";

  static const String docerAnimation =
      "assets/images/social_media/email_sent2.gif";
}
