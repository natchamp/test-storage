import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:practice/common/widgets/loaders/animation_loader.dart';
import 'package:practice/utils/constants/colors.dart';
import 'package:practice/utils/helpers/helper_functions.dart';

class TFullScreenLoader {
  //Parameters
  //  -text : text to be displayed in the loading dialog
  //  -animation : the lattie animation to be shown
  static void openLoadingDialog(String text, String animation) {
    showDialog(
        context: Get.overlayContext!,
        barrierDismissible: false,
        builder: (_) => PopScope(
            canPop: false,
            child: Container(
              color: THelperFunctions.isDarkMode(Get.context!)
                  ? TColors.dark
                  : TColors.white,
              width: double.infinity,
              height: double.infinity,
              child: Column(
                children: [
                  const SizedBox(
                    height: 250,
                  ),
                  TAnimationLoaderWidget(text: text, animation: animation)
                ],
              ),
            )));
  }

  /// Stop the currently open loading dialog.
  /// This method doesn't return anything.
  static stopLoading() {
    Navigator.of(Get.overlayContext!)
        .pop(); // Close the dialog using the Navigator
  }
}
