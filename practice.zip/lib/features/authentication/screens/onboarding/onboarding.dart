import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:practice/features/authentication/controllers/onboarding/onboarding_controller.dart';
import 'package:practice/features/authentication/screens/onboarding/widgets/onboarding_dot_navigation.dart';
import 'package:practice/features/authentication/screens/onboarding/widgets/onboarding_next_button.dart';
import 'package:practice/features/authentication/screens/onboarding/widgets/onboarding_page.dart';
import 'package:practice/features/authentication/screens/onboarding/widgets/onboarding_skip.dart';
import 'package:practice/utils/constants/image_strings.dart';
import 'package:practice/utils/constants/texts.dart';

class OnBoardingScreen extends StatelessWidget {
  const OnBoardingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(OnBoardingController());

    //return const Scaffold(
    return Scaffold(
      body: Stack(
        children: [
          PageView(
            controller: controller.pageController,
            onPageChanged: controller.updatePageIndicator,
            children: const [
              OnBoardingPage(
                  image: TImages.ob1,
                  title: TTexts.obH1,
                  subTitle: TTexts.obT1),
              OnBoardingPage(
                  image: TImages.ob2,
                  title: TTexts.obH2,
                  subTitle: TTexts.obT2),
              OnBoardingPage(
                  image: TImages.ob3,
                  title: TTexts.obH3,
                  subTitle: TTexts.obT3),
            ],
          ),
          //skip navigaation
          const OnBoardingSkip(),
          //dot navigation
          const OnBoardingDotNavigation(),
          //circular button
          const OnboardingNextButton()
        ],
      ),
    );
  }
}
