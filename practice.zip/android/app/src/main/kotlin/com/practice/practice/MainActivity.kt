package com.practice.practice

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
